<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'AiUitZDLQ6kRWImZuc8wKqfg2xC+RVlBRU3nUsoXKK5jsUdj/zqnTrUe4bKxy/2GUVbFQZE/z8OX50zHWevirA==');
define('SECURE_AUTH_KEY',  'MB2YqbJBfO/Ecevzp6FF1e1Cf6+9Kwc7gOyIOUij7Cju6YEZWzrsmIZ4PsSFGS5gthSOa2TOKho9dsGfrqgTBA==');
define('LOGGED_IN_KEY',    'OzGZPKH6mnUxp5FSFO2Rrn8CHwfuCw4JVMYoHjYbTU7altQdFeX7Nl6EfjQzg4gbDYqBw/EcZgv9l9qUNgYsSA==');
define('NONCE_KEY',        '3BOBjOXH/FPqhX+TW1uNQ8ILL0AzuB4Uiv70xw8I0m3Eb2P8zE2bZ38omclp7V0RMaS2LDzMFayf4EEW6ZkFLQ==');
define('AUTH_SALT',        '0jH+AH35aNize9dYxF6sSA2W8EokKKGzru9n0x52nhCb4MTOhbKtEsAvqkE3L4ixNXb50e6zEoJG+im0LhTMqw==');
define('SECURE_AUTH_SALT', 'fyFjyoqjXW+Zi8ZBoY4a5k8sMxWIzPVTEybwEQS5aSjhQzELtUFMmToUe4d3C0Z7eAiEFw0EFk9DQ03r2diz9Q==');
define('LOGGED_IN_SALT',   'SYuzlZGSqnE5wfdyOInXkkX9HAytRt7uBqX1OB3ox4sew8pAEbDYhKrB0eUQU78bV07a6AohH2m9QFCxcnpVAA==');
define('NONCE_SALT',       'JvhPIeNTLxp5r4s33SMDqNe8frBxYLavTvA32rAPB0rgbkHSymgVpH+1NiHSaFpJsr8kRFa1omyqiFx0UVC08w==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
